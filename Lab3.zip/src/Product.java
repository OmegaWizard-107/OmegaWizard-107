public interface Product {

    public double getTotalPrice();
    public boolean isTaxable();
    
}
